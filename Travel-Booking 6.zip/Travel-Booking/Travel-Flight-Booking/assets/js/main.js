// Common script file
console.log("TravelBook Website Loaded!");
